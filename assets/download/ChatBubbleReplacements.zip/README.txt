# Chat bubbles in protected areas

Chat bubble texture replacements.  
They will work in open world and in protected areas such as Dungeons & Raids.  
If you prefer this style, make sure to disable ElvUI chat bubble skinning ingame.

/ec -> General -> Cosmetic -> Scroll down -> Chat Bubbles Style (DropDown) -> Set to "Disable"

# How to install

1) Download the .zip from the link below  
2) Right-click and click on "Extract All..."  
3) Choose a style (Invisible, Small, Medium, Large)  
4) Right-click the style and click on "Extract All..."  
5) Then move the subfolder (Called "Tooltips") to:  
- `World of Warcraft\[WOW VERSION]\Interface`

[WOW VERSION]  
`_retail_` for The War Within  
`_classic_` for Mists of Pandaria Classic  
`_classic_era` for Classic, Seasons, Hardcore
`_anniversary_` for Anniversary

If you have file name extensions displayed it will append ".tga" - this is fine.

# Showcase - Style "Invisible"
https://i.imgur.com/ncXU3O1.png

# Showcase - Style "Small"
https://i.imgur.com/s2wfkpS.png
# Showcase - Style "Medium"
https://i.imgur.com/8o5zeqy.png

# Showcase - Style "Large"
https://i.imgur.com/ICqooab.png

# Links
Guide - https://github.com/tukui-org/ElvUI/wiki/chat-bubble-replacements
